from tkinter import *
import math as m
from PIL import Image, ImageTk
import math

window = Tk()
window.geometry("380x640+470+20")#Size Of The GUI
window.title("APP2 Calculator")
window.config(bg="gray11")
window.resizable(True, False)

image_path = "image/Capture.png"  # Image 
photo = PhotoImage(file=image_path)
image_label = Label(window, image=photo, border=0)
image_label.grid(row=0, columnspan=4)

pi = m.pi #PI

#Close Window Function
def close():
    window.destroy()

#Clear Function
def clear():
    entry.delete(0, "end")

#Back Function
def back():
    lastnum = len(entry.get())
    entry.delete(lastnum-1)  

def press(input_str):
    if input_str == 'π':
        input_str = str(math.pi)
    current_text = entry.get()
    new_text = current_text + str(input_str)
    entry.delete(0, END)
    entry.insert(0, new_text)

#Addition +
def add(a, b):
    return float(a) + float(b)

#substitution -
def sub(a, b):
    return float(a) - float(b)

#division :
def div(a, b):
    if b == 0:
        return "Error"
    return float(a) / float(b)

#multiplication *
def multiply(a, b):
    return float(a) * float(b)

#Power ^
def power(a, b):
    return float(a) ** float(b)

#Factorial !
def factorial(a):
    if a < 0:
        return "ERROR: Factorial is not defined for negative numbers"#If Number less than 0
    elif a == 0 or a == 1:
        return 1
    else:
        result = 1
        for i in range(2, int(a) + 1):
            result *= i
        return result

#Remainder
def remainder(a, b):
    return a % b

def expression_break(sign, expression):
    values = expression.split(sign, 1)  
    return values

#Equal=
def equal():
    expression = entry.get()
    clear()
    try:
        expression = expression.replace('π', str(pi))  # replace π with pi
        # Check if expression contains a function
        functions = ["sin", "cos", "tan", "sqrt", "log", "ln", "degree", "radian", "factorial", "rem"]#all functions in our Calculator
        function_found = False
        for func in functions:
            if func in expression:
                data = expression_break("(", expression)
                if func == "sin":
                    result = m.sin(m.radians(float(data[1])))
                elif func == "cos":
                    result = m.cos(m.radians(float(data[1])))
                elif func == "tan":
                    result = m.tan(m.radians(float(data[1])))
                elif func == "sqrt":
                    result = m.sqrt(float(data[1]))
                elif func == "log" or func == "ln":
                    result = m.log(float(data[1]))
                elif func == "degree":
                    result = m.degrees(float(data[1]))
                elif func == "radian":
                    result = m.radians(float(data[1]))
                elif func == "factorial":
                    result = factorial(float(data[1]))
                elif func == "rem":
                    data = expression_break(",", expression)
                    result = remainder(float(data[0]), float(data[1]))

                function_found = True
                break

        if function_found:
            entry.insert(0, result)
        else:
            # Check if expression contains an operation
            operators = ["+", "-", "*", "/", "^"]
            operation_found = False
            for operator in operators:
                if operator in expression:
                    data = expression_break(operator, expression)
                    if operator == "+":
                        result = add(data[0], data[1])
                    elif operator == "-":
                        result = sub(data[0], data[1])
                    elif operator == "*":
                        result = multiply(data[0], data[1])
                    elif operator == "/":
                        result = div(data[0], data[1])
                    elif operator == "^":
                        result = power(data[0], data[1])
                    operation_found = True
                    break

            if operation_found:
                entry.insert(0, result)
            else:
                entry.insert(0, "Invalid Expression")

    except Exception as e:
        entry.insert(0, "ERROR: " + str(e))


entry_string = StringVar()
entry = Entry(window, textvariable=entry_string, foreground="white", background="Navy", border=0, font=("calibri semibold", 26))
entry.grid(row=1, columnspan=4, ipady=10)

#PlaceHolder
def add_placeholder(event):
    
    if entry_string.get() == '':
        entry.config(foreground='gray')
        entry_string.set('Enter')

#Function To Clear The PlaceHolder
def clear_placeholder(event):
    
    if entry_string.get() == 'Enter':
        entry.delete(0, END)
        entry.config(foreground='white')

# Bind the entry widget with focus in and focus out events
entry.bind("<FocusIn>", clear_placeholder)
entry.bind("<FocusOut>", add_placeholder)

# Initialize the placeholder
entry_string.set('Enter')
entry.config(foreground='light gray')


font_value = ("calibri", 18)
tan = Button(window, text="tan", background="light gray", foreground="Navy", font=font_value, borderwidth=1, relief=SOLID,command=lambda:press("tan("))
tan.grid(row=2, column=0, sticky=E+W, ipady=5) #Tan Button

cos = Button(window, text="cos", background="light gray", foreground="Navy", font=font_value, borderwidth=1, relief=SOLID,command=lambda:press("cos("))
cos.grid(row=2, column=1, sticky=E+W, ipady=5)#Cos Button

sin = Button(window, text="sin", background="light gray", foreground="Navy", font=font_value, borderwidth=1, relief=SOLID,command=lambda:press("sin("))
sin.grid(row=2, column=2, sticky=E+W, ipady=5)#Sin Button

sqrt = Button(window, text="sqrt", background="light gray", foreground="Navy", font=font_value, borderwidth=1, relief=SOLID,command=lambda:press("sqrt("))
sqrt.grid(row=2, column=3, sticky=E+W, ipady=5)#Sqrt Button
#row3
log = Button(window, text="log", background="light gray", foreground="Navy", font=font_value, borderwidth=1, relief=SOLID,command=lambda:press("log("))
log.grid(row=3, column=0, sticky=E+W, ipady=5)#log Button

ln = Button(window, text="ln", background="light gray", foreground="Navy", font=font_value, borderwidth=1, relief=SOLID,command=lambda:press("ln("))
ln.grid(row=3, column=1, sticky=E+W, ipady=5)#Ln Button

degree = Button(window, text="deg", background="light gray", foreground="Navy", font=font_value, borderwidth=1, relief=SOLID,command=lambda:press("deg("))
degree.grid(row=3, column=2, sticky=E+W, ipady=5)#Deg Button

rad = Button(window, text="rad", background="light gray", foreground="Navy", font=font_value, borderwidth=1, relief=SOLID,command=lambda:press("rad("))
rad.grid(row=3, column=3, sticky=E+W, ipady=5)#Rad Button

#row4
fac = Button(window, text="fac", background="light gray", foreground="Navy", font=font_value, borderwidth=1, relief=SOLID,command=lambda:press("factorial("))
fac.grid(row=4, column=0, sticky=E+W, ipady=5)#Factorial Button

pow = Button(window, text="^", background="light gray", foreground="Navy", font=font_value, borderwidth=1, relief=SOLID,command=lambda:press("^"))
pow.grid(row=4, column=1, sticky=E+W, ipady=5)#Power Button

rem = Button(window, text="rem", background="light gray", foreground="Navy", font=font_value, borderwidth=1, relief=SOLID,command=lambda:press("remainder("))
rem.grid(row=4, column=2, sticky=E+W, ipady=5)#Remainder Button

pi = Button(window, text="π", background="light gray", foreground="Navy", font=font_value, borderwidth=1, relief=SOLID, command=lambda: press('π'))
pi.grid(row=4, column=3, sticky=E+W, ipady=5)#Pi Button

#row5
clear_button = Button(window, text="C", background="light gray", foreground="Navy", font=font_value, borderwidth=1, relief=SOLID,command=clear)
clear_button.grid(row=5,columnspan=2, column=0, sticky=E+W, ipady=5)#Clear Button

backspace = Button(window, text="B", background="light gray", foreground="Navy", font=font_value, borderwidth=1, relief=SOLID,command=back)
backspace.grid(row=5,columnspan=2, column=2, sticky=E+W, ipady=5)#Back Button

#row6
btn7 = Button(window, text="7", background="light gray", foreground="Navy", font=font_value, borderwidth=1, relief=SOLID,command=lambda:press(7))
btn7.grid(row=6, column=0, sticky=E+W, ipady=5)

btn8 = Button(window, text="8", background="light gray", foreground="Navy", font=font_value, borderwidth=1, relief=SOLID,command=lambda:press(8))
btn8.grid(row=6, column=1, sticky=E+W, ipady=5)

btn9 = Button(window, text="9", background="light gray", foreground="Navy", font=font_value, borderwidth=1, relief=SOLID,command=lambda:press(9))
btn9.grid(row=6, column=2, sticky=E+W, ipady=5)

division = Button(window, text=":", background="Navy", foreground="Light gray", font=font_value, borderwidth=1, relief=SOLID,command=lambda:press("/"))
division.grid(row=6, column=3, sticky=E+W, ipady=5)#Division Button

#row7
btn4 = Button(window, text="4", background="light gray", foreground="Navy", font=font_value, borderwidth=1, relief=SOLID,command=lambda:press(4))
btn4.grid(row=7, column=0, sticky=E+W, ipady=5)

btn5 = Button(window, text="5", background="light gray", foreground="Navy", font=font_value, borderwidth=1, relief=SOLID,command=lambda:press(5))
btn5.grid(row=7, column=1, sticky=E+W, ipady=5)

btn6 = Button(window, text="6", background="light gray", foreground="Navy", font=font_value, borderwidth=1, relief=SOLID,command=lambda:press(6))
btn6.grid(row=7, column=2, sticky=E+W, ipady=5)

multiplication = Button(window, text="x", background="Navy", foreground="Light gray", font=font_value, borderwidth=1, relief=SOLID,command=lambda:press("*"))
multiplication.grid(row=7, column=3, sticky=E+W, ipady=5)#Multiplication Button

#row8
btn1 = Button(window, text="1", background="light gray", foreground="Navy", font=font_value, borderwidth=1, relief=SOLID,command=lambda:press(1))
btn1.grid(row=8, column=0, sticky=E+W, ipady=5)

btn2 = Button(window, text="2", background="light gray", foreground="Navy", font=font_value, borderwidth=1, relief=SOLID,command=lambda:press(2))
btn2.grid(row=8, column=1, sticky=E+W, ipady=5)

btn3 = Button(window, text="3", background="light gray", foreground="Navy", font=font_value, borderwidth=1, relief=SOLID,command=lambda:press(3))
btn3.grid(row=8, column=2, sticky=E+W, ipady=5)

minus = Button(window, text="-", background="Navy", foreground="Light gray", font=font_value, borderwidth=1, relief=SOLID,command=lambda:press("-"))
minus.grid(row=8, column=3, sticky=E+W, ipady=5)#Minus Button



#row10
point = Button(window, text=".", background="light gray", foreground="Navy", font=font_value, borderwidth=1, relief=SOLID,command=lambda:press("."))
point.grid(row=10, column=0, sticky=E+W, ipady=5)#Point Button

zero = Button(window, text="0", background="light gray", foreground="Navy", font=font_value, borderwidth=1, relief=SOLID,command=lambda:press(0))
zero.grid(row=10, column=1, sticky=E+W, ipady=5)

exp = Button(window, text="e", background="light gray", foreground="Navy", font=font_value, borderwidth=1, relief=SOLID,command=lambda:press(2.7182818))
exp.grid(row=10, column=2, sticky=E+W, ipady=5)#Exponentiel Button

plus = Button(window, text="+", background="Navy", foreground="Light gray", font=font_value, borderwidth=1, relief=SOLID,command=lambda:press("+"))
plus.grid(row=10, column=3, sticky=E+W, ipady=5)#Addition Button

#row11
equal = Button(window, text="=", background="Navy", foreground="white", font=font_value, borderwidth=1, relief=SOLID,command=equal)
equal.grid(row=11,columnspan=3, column=0, sticky=E+W, ipady=5)#Equal Button

backspace = Button(window, text="close", background="Light Gray", foreground="Navy", font=font_value, borderwidth=1, relief=SOLID,command=close)
backspace.grid(row=11,columnspan=1, column=3, sticky=E+W, ipady=5 )#Close

mainloop()